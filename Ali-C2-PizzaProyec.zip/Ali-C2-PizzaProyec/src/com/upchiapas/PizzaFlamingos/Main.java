package com.upchiapas.PizzaFlamingos;

import com.upchiapas.PizzaFlamingos.models.CatalagoTickets;
import com.upchiapas.PizzaFlamingos.models.CatalogoPizza;
import com.upchiapas.PizzaFlamingos.models.Pizzeria;

public class Main {

    public static void main(String[] args) {

        Pizzeria Ejecute=new Pizzeria();
        System.out.println("hey the, Here in main");
        Ejecute.MuestraMenu();

    }
}
