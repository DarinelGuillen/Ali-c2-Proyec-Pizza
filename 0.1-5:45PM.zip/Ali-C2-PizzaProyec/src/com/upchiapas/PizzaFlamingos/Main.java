package com.upchiapas.PizzaFlamingos;

import com.upchiapas.PizzaFlamingos.models.CatalogoPizza;
import com.upchiapas.PizzaFlamingos.models.Pizzeria;

public class Main {

    public static void main(String[] args) {
        CatalogoPizza D=new CatalogoPizza();
        Pizzeria Ejecute=new Pizzeria();

        D.AddCatalagoPredeterminados();

        System.out.println("public static void main(String[] args)");


        Ejecute.MuestraMenu();

    }
}
