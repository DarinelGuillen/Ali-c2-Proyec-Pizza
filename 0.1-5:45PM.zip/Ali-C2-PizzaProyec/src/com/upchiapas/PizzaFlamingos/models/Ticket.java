package com.upchiapas.PizzaFlamingos.models;

public class Ticket {

}
