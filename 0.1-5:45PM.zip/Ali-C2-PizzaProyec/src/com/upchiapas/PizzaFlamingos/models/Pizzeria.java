package com.upchiapas.PizzaFlamingos.models;

import com.upchiapas.PizzaFlamingos.Main;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import java.util.Scanner;

public class Pizzeria {
static Scanner T=new Scanner(System.in);
    CatalogoPizza Cat=new CatalogoPizza();
 public void MuestraMenu(){
        Cat.AddCatalagoPredeterminados();
     System.out.println("Holitassss==");
     System.out.println("Hey there Insert a number ");
     System.out.println("1.Mostrar catalago ");
     System.out.println("2.Agregar Pizza nueva\n");
     byte opc=T.nextByte();
     switch (opc) {
         case 1:
             Cat.ShowCatalagoPizza();
             break;
         case 2:
             Cat.AddNewPizzaMenu();
             break;
         case 3: break;
     }


 }



 }



