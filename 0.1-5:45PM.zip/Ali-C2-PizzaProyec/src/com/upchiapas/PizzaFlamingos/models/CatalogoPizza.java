package com.upchiapas.PizzaFlamingos.models;

import java.util.ArrayList;
import java.util.Scanner;

public class CatalogoPizza {

    //Arreglos de pizza

        Scanner T = new Scanner(System.in);
        ArrayList<Pizza> Catalago = new ArrayList<>();

        public void AddCatalagoPredeterminados () {

            Catalago.add(new Pizza((byte) 1, "Hawaiana", (float) 120));
            Catalago.add(new Pizza((byte) 2, "Orillas de queso", (float) 230));
            Catalago.add(new Pizza((byte) 2, "Peperoni", (float) 130));
            Catalago.add(new Pizza((byte) 3, "4 quesos", (float) 200));
            Catalago.add(new Pizza((byte) 4, "Mexicana", (float) 100));
            Catalago.add(new Pizza((byte) 5, "Chiken Hawaiana", (float) 300));


        }
        public void AddNewPizzaMenu () {
            Pizzeria R = new Pizzeria();
            System.out.println("Ustes esta por agregar un nueva pizza");
            short id = (short) Catalago.size();
            System.out.println("Ingrese el nombre de la Pizza nueva");
            String NombrePizza = T.nextLine();
            System.out.println("Ingrese el precio de la Pizza");
            int Precio = T.nextInt();
            Catalago.add(new Pizza((byte) id, NombrePizza, (float) Precio));
            R.MuestraMenu();
        }
        public void ShowCatalagoPizza () {
            Pizzeria R = new Pizzeria();
            for (int i = 0; i < Catalago.size(); i++) {
                System.out.println("" + Catalago.get(i));
            }
            R.MuestraMenu();
        }

}
